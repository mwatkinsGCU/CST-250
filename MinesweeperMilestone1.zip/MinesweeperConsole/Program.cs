﻿using MinesweeperLogic;

namespace MinesweeperConsole
{
    internal class Program
    {
        private static void PrintAnswers(Board board)
        {
            int size = board.Size;
            for (int idx = 0; idx < size; idx++)
            {
                Console.Write("+---");
                if (idx == size - 1)
                {
                    Console.WriteLine("+");
                }
            }
            for (int boardIdx = 0; boardIdx < size; boardIdx++)
            {
                Console.Write("| ");
                for (int idx = 0; idx < size; idx++)
                {
                    if (board.Cells[boardIdx, idx].IsBomb)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("B");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else if (board.Cells[boardIdx, idx].NumberOfBombNeighbors == 0)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        switch (board.Cells[boardIdx, idx].NumberOfBombNeighbors)
                        {
                            case 1:
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 2:
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 3:
                                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 4:
                                Console.ForegroundColor = ConsoleColor.DarkYellow;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 5:
                                Console.ForegroundColor = ConsoleColor.DarkRed;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 6:
                                Console.ForegroundColor = ConsoleColor.DarkBlue;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 7:
                                Console.ForegroundColor = ConsoleColor.Magenta;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 8:
                                Console.ForegroundColor = ConsoleColor.DarkGreen;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            default:
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                        }

                    }
                    if (idx == size - 1)
                    {
                        Console.WriteLine(" |");
                    }
                    else
                    {
                        Console.Write(" | ");
                    }
                }
                for (int idxR = 0; idxR < size; idxR++)
                {
                    Console.Write("+---");
                    if (idxR == size - 1)
                    {
                        Console.WriteLine("+");
                    }
                }
            }  
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello, welcome to Minesweeper");
            // size 10 and difficulty 0.1
            Board board = new Board(10, 0.1);
            Console.WriteLine("Here is the answer key for the first board");
            PrintAnswers(board);

            // size 15 and difficulty 0.15
            board = new Board(15, 0.15);
            Console.WriteLine("Here is the answer key for the second board");
            PrintAnswers(board);
        }
    }
}
