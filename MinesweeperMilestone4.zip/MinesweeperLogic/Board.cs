﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MinesweeperLogic
{
    public class Board
    {
        // create the properties with get and set
        public int Size { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public Cell[,] Cells { get; set; }
        public double DiffPercent { get; set; }
        public int RewardsRemaining { get; set; }
        public int RewardsUsed { get; set; }
        public int numBombs { get; set; }
        public int numClickedBombs { get; set; }
        public int numVisited { get; set; }
        public enum GameState { InProgress, Win, Loss }

        // constructor
        public Board(int size, double difficulty)
        {
            Size = size;
            DiffPercent = difficulty;
            Cells = new Cell[size, size];
            RewardsRemaining = 0;
            RewardsUsed = 0;
            numClickedBombs = 0;
            EndTime = DateTime.MinValue;
            InitializeBoard();
        }

        // method to call submethods to init the board
        private void InitializeBoard()
        {
            // init Cells array
            for (int idxR = 0; idxR < Size; idxR++)
            {
                for (int idxC = 0; idxC < Size; idxC++)
                {
                    Cells[idxR, idxC] = new Cell(idxR, idxC);

                }
            }
            SetupBombs();
            SetupReward();
            CountBombsNearby();
            StartTime = DateTime.Now;
        }

        // used when a player selects a cell and chooses to use the reward
        public string UseSpecialReward(int row, int col)
        {
            RewardsUsed++;
            if (Cells[row, col].IsBomb)
            {
                string message = "There is a bomb at cell " + row + ", " + col;
                RewardsRemaining--;
                return message;
            }
            else
            {
                string message = "There is no bomb at cell " + row + ", " + col;
                RewardsRemaining--;
                return message;
            }
        }

        // used during the game is over to calculate the score
        public int DetermineScore(TimeSpan time)
        {
            double score = - (time.TotalMilliseconds) - (1000 * RewardsUsed) + ((GetVisited() - numClickedBombs) * 100) - (5000 * numClickedBombs);
            return (int)score;
        }

        // used after the game is over to calculate the final score
        public int DetermineScore()
        {
            double score = (EndTime - StartTime).TotalMilliseconds - (1000 * RewardsUsed) + ((GetVisited() - numClickedBombs) * 100) - (5000 * numClickedBombs);
            return (int)score;
        }

        // method to get number of visited cells on board
        public int GetVisited()
        {
            foreach (Cell cell in Cells)
            {
                if (cell.IsVisited)
                {
                    numVisited++;
                }
            }
            return numVisited;
        }

        // method to determine if a cell is on the board
        public bool IsCellOnBoard(int row, int col)
        {
            if (row < 0 || col < 0)
                return false;

            if (row >= Size || col >= Size)
                return false;

            return true;
        }

        // method to set up bombs across the board
        private void SetupBombs()
        {
            foreach (Cell cell in Cells)
            {
                // generate a random number between 0 and 1
                Random rand = new Random();
                double genDiff = rand.NextDouble();

                // check if random number is less than or equal to difficulty level
                if (genDiff <= DiffPercent)
                {
                    cell.IsBomb = true;
                    numBombs++;
                }
                else
                {
                    cell.IsBomb = false;
                }
            }
        }

        // method to set up bombs across the board
        private void SetupReward()
        {
            if (DiffPercent >= 0.05 && DiffPercent < 0.12)
            {
                // generate two random numbers between 0 and the board size, will be used as row and column of the reward
                Random rand = new Random();
                int rewardRow = rand.Next(0, Size);
                int rewardCol = rand.Next(0, Size);
                Cells[rewardRow, rewardCol].HasReward = true;
            }
            else if (DiffPercent >= 0.12 && DiffPercent < 0.19)
            {
                for (int i = 0; i < 2; i++)
                {
                    // generate two random numbers between 0 and the board size, will be used as row and column of the reward
                    Random rand = new Random();
                    int rewardRow = rand.Next(0, Size);
                    int rewardCol = rand.Next(0, Size);
                    Cells[rewardRow, rewardCol].HasReward = true;
                }
            }
            else if (DiffPercent >= 0.19)
            {
                for (int i = 0; i < 3; i++)
                {
                    // generate two random numbers between 0 and the board size, will be used as row and column of the reward
                    Random rand = new Random();
                    int rewardRow = rand.Next(0, Size);
                    int rewardCol = rand.Next(0, Size);
                    Cells[rewardRow, rewardCol].HasReward = true;
                }
            }
        }

        // method to determine how many neighbors are bombs
        private void CountBombsNearby()
        {
            for (int idxRow = 0; idxRow < Size; idxRow++)
            {
                for (int idxCol = 0; idxCol < Size; idxCol++)
                {
                    if (Cells[idxRow, idxCol].IsBomb)
                    {
                        // if cell is a bomb, set neighbors to 9
                        Cells[idxRow, idxCol].NumberOfBombNeighbors = 9;
                    }
                    else
                    {
                        // check surrounding cells for bombs and set result to the property
                        Cells[idxRow, idxCol].NumberOfBombNeighbors = GetNumberOfBombNeighbors(idxRow, idxCol);
                    }
                }
            }
        }

        // method to print the updated game board
        public void UpdateGameBoard(Board board)
        {
            int size = board.Size;
            for (int idx = 0; idx < size; idx++)
            {
                Console.Write("+---");
                if (idx == size - 1)
                {
                    Console.WriteLine("+");
                }
            }
            for (int boardIdx = 0; boardIdx < size; boardIdx++)
            {
                Console.Write("| ");
                for (int idx = 0; idx < size; idx++)
                {
                    if (board.Cells[boardIdx, idx].IsVisited)
                    {
                        if (board.Cells[boardIdx, idx].IsBomb)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write("B");
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                        else if (board.Cells[boardIdx, idx].HasReward)
                        {
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.Write("r");
                            Console.ForegroundColor = ConsoleColor.White;
                            board.Cells[boardIdx, idx].HasReward = false;
                        }
                        else if (board.Cells[boardIdx, idx].NumberOfBombNeighbors == 0)
                        {
                            Console.Write(".");
                        }
                        else
                        {
                            // Console.ForegroundColor = GetColorForBombCount(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                            Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                    }
                    else if (board.Cells[boardIdx, idx].IsFlagged)
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write("F");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write("?");
                    }
                    if (idx == size - 1)
                    {
                        Console.WriteLine(" |");
                    }
                    else
                    {
                        Console.Write(" | ");
                    }
                }
                for (int idxR = 0; idxR < size; idxR++)
                {
                    Console.Write("+---");
                    if (idxR == size - 1)
                    {
                        Console.WriteLine("+");
                    }
                }
            }
        }

        // method to return color based on the number of bomb neighbors
        public Color GetColorForBombCount(int bombCount)
        {
            return bombCount switch
            {
                1 => Color.Cyan,
                2 => Color.Green,
                3 => Color.DarkMagenta,
                4 => Color.DarkGoldenrod,
                5 => Color.DarkRed,
                6 => Color.DarkBlue,
                7 => Color.Magenta,
                8 => Color.DarkGreen,
                _ => Color.White,
            };
        }

        // helper method to determine the number of bomb neighbors for each cell
        private int GetNumberOfBombNeighbors(int row, int col)
        {
            int total = 0;

            if (IsCellOnBoard(row - 1, col - 1))
            {
                if (Cells[(row - 1), (col - 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row - 1, col))
            {
                if (Cells[(row - 1), (col)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row - 1, col + 1))
            {
                if (Cells[(row - 1), (col + 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row, col - 1))
            {
                if (Cells[(row), (col - 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row, col + 1))
            {
                if (Cells[(row), (col + 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row + 1, col - 1))
            {
                if (Cells[(row + 1), (col - 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row + 1, col))
            {
                if (Cells[(row + 1), (col)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row + 1, col + 1))
            {
                if (Cells[(row + 1), (col + 1)].IsBomb)
                {
                    total++;
                }
            }

            return total;
        }

        public void FloodFill(int row, int col)
        {
            // Check if the cell is valid
            if (row < 0 || row >= Cells.GetLength(0) || col < 0 || col >= Cells.GetLength(1))
                return;

            // If the cell is already visited, return
            if (Cells[row, col].IsVisited)
                return;

            // Perform the update using the provided delegate
            if (Cells[row, col].IsBomb)
            {
                return; // Stop if it's a bomb
            }

            // Check for rewards
            if (Cells[row, col].HasReward)
            {
                return; // Stop if it's a reward
            }

            // Mark the cell as visited
            Cells[row, col].IsVisited = true;

            // If there are bomb neighbors, end the loop
            if (Cells[row, col].NumberOfBombNeighbors > 0)
            {
                Cells[row, col].IsVisited = false; // Unmark the cell as visited
                return;
            }

            // Update button to empty and continue flood fill on neighboring cells
            FloodFill(row, col - 1); // West
            FloodFill(row, col + 1); // East
            FloodFill(row - 1, col); // North
            FloodFill(row + 1, col); // South
        }
    }
}
