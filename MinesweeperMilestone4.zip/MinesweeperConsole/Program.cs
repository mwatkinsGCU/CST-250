﻿using MinesweeperLogic;
using System.Data;
using System.Runtime.CompilerServices;

namespace MinesweeperConsole
{
    internal class Program
    {
        private static void PrintAnswers(Board board)
        {
            int size = board.Size;
            for (int idx = 0; idx < size; idx++)
            {
                Console.Write("+---");
                if (idx == size - 1)
                {
                    Console.WriteLine("+");
                }
            }
            for (int boardIdx = 0; boardIdx < size; boardIdx++)
            {
                Console.Write("| ");
                for (int idx = 0; idx < size; idx++)
                {
                    if (board.Cells[boardIdx, idx].IsBomb)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("B");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else if (board.Cells[boardIdx, idx].HasReward)
                    {
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write("r");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else if (board.Cells[boardIdx, idx].NumberOfBombNeighbors == 0)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        switch (board.Cells[boardIdx, idx].NumberOfBombNeighbors)
                        {
                            case 1:
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 2:
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 3:
                                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 4:
                                Console.ForegroundColor = ConsoleColor.DarkYellow;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 5:
                                Console.ForegroundColor = ConsoleColor.DarkRed;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 6:
                                Console.ForegroundColor = ConsoleColor.DarkBlue;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 7:
                                Console.ForegroundColor = ConsoleColor.Magenta;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case 8:
                                Console.ForegroundColor = ConsoleColor.DarkGreen;
                                Console.Write(board.Cells[boardIdx, idx].NumberOfBombNeighbors);
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            default:
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                        }

                    }
                    if (idx == size - 1)
                    {
                        Console.WriteLine(" |");
                    }
                    else
                    {
                        Console.Write(" | ");
                    }
                }
                for (int idxR = 0; idxR < size; idxR++)
                {
                    Console.Write("+---");
                    if (idxR == size - 1)
                    {
                        Console.WriteLine("+");
                    }
                }
            }  
        }

        // method to ask player to select a row
        private static int CheckRow(Board board, int row)
        {
            bool checkRow = true;
            while (checkRow)
            {
                Console.WriteLine("What row would you like to select? ");
                if (!(int.TryParse(Console.ReadLine(), out row)))
                {
                    Console.WriteLine("Please select a valid row (0 - " + (board.Size - 1) + ")");
                    continue;
                }
                if (row >= board.Size || row < 0)
                {
                    Console.WriteLine("Please select a valid row (0 - " + (board.Size - 1) + ")");
                    continue;
                }
                checkRow = false;
            }
            return row;
        }

        // method to ask player to select a row
        private static int CheckCol(Board board, int col)
        {
            bool checkRow = true;
            while (checkRow)
            {
                Console.WriteLine("What column would you like to select? ");
                if (!(int.TryParse(Console.ReadLine(), out col)))
                {
                    Console.WriteLine("Please select a valid column (0 - " + (board.Size - 1) + ")");
                    continue;
                }
                if (col >= board.Size || col < 0)
                {
                    Console.WriteLine("Please select a valid column (0 - " + (board.Size - 1) + ")");
                    continue;
                }
                checkRow = false;
            }
            return col;
        }

        // method to check for action after selecting a cell and return a death or not
        private static bool TakeAction(Board board, int row, int col)
        {
            // action logic
            bool checkAction = true;
            while (checkAction)
            {
                Console.WriteLine("What would you like to do on cell " + row + ", " + col + "? ");
                string answer = Console.ReadLine().ToLower();
                if (answer.Equals("flag"))
                {
                    if (!(board.Cells[row, col].IsFlagged))
                    {
                        board.Cells[row, col].IsFlagged = true;
                        Console.WriteLine("Cell " + row + ", " + col + " flagged.");
                    }
                    else
                    {
                        board.Cells[row, col].IsFlagged = false;
                        Console.WriteLine("Cell " + row + ", " + col + " unflagged.");
                    }
                    checkAction = false;
                }
                else if (answer.Equals("visit"))
                {
                    // check how many bomb neighbors cell has
                    if (board.Cells[row, col].NumberOfBombNeighbors > 0 || board.Cells[row, col].IsBomb || board.Cells[row, col].HasReward)
                    {
                        board.Cells[row, col].IsVisited = true;
                    }
                    // check if cell is bomb
                    if (board.Cells[row, col].IsBomb)
                    {
                        Console.Clear();
                        Console.WriteLine("You hit a mine! You lose!");
                        return checkAction;
                    }
                    // if cell is a reward the only reveal the reward and increase RemainingRewards by 1
                    if (board.Cells[row, col].HasReward)
                    {
                        Console.WriteLine("You found the reward!");
                        board.RewardsRemaining++;
                    }
                    // if cell has 0 bomb neighbors, reveal all connected 0 bomb neighbor cells
                    if (board.Cells[row, col].NumberOfBombNeighbors == 0 && !(board.Cells[row, col].HasReward))
                    {
                        // board.FloodFill(row, col);
                    }
                    checkAction = false;
                    return checkAction;
                }
                else if (answer.Equals("reward"))
                {
                    if (board.RewardsRemaining > 0)
                    {
                        if (board.Cells[row, col].IsBomb)
                        {
                            Console.WriteLine("Cell " + row + ", " + col + " contains a bomb.");
                            checkAction = false;
                            board.RewardsRemaining--;
                            return checkAction;
                        }
                        else
                        {
                            Console.WriteLine("Cell " + row + ", " + col + " does not contain a bomb.");
                            checkAction = false;
                            board.RewardsRemaining--;
                            return checkAction;
                        }
                    }
                    else
                    {
                        Console.WriteLine("No rewards to use!");
                        continue;
                    }
                }
                else
                {
                    Console.WriteLine("Please select a valid action (flag, visit, reward) ");
                    continue;
                }
            }
            return checkAction;
        }

        // method to check for win condition
        private static bool CheckWinCondition(int nonBombs)
        {
            if (nonBombs == 0)
            {
                Console.WriteLine("Congratulations! You hit no bombs and won the game!");
                return true;
            }
            return false;
        }

        static void Main(string[] args)
        {
            // create variables
            bool victory = false; // if true player win
            bool death = false; // if true player loss
            // variables for checking rows/columns
            int row = 0;
            int col = 0;

            Console.WriteLine("Hello, welcome to Minesweeper");

            // Default game - size 5 and difficulty 0.1
            Board board = new Board(5, 0.1);
            PrintAnswers(board);

            board.UpdateGameBoard(board);

            // repeat loop until game over
            while (!(victory) && !(death))
            {
                // get row and column inputs
                row = CheckRow(board, row);
                col = CheckCol(board, col);

                // ask what to do with cell/update death variable if needed
                death = TakeAction(board, row, col);
                
                if (victory || death)
                {
                    PrintAnswers(board); // print the answers if game over
                }
                else
                {
                    // variables for how many non-bombs
                    int nonBombs = (board.Size * board.Size) - board.numBombs - board.GetVisited();
                    // clear console and reshow number of non-bombs remaining
                    Console.Clear();
                    Console.WriteLine("Non-Bomb Cells Remaining: " + nonBombs);
                    board.numVisited = 0;
                    victory = CheckWinCondition(nonBombs);

                    board.UpdateGameBoard(board); // update the board after taking an action
                }
            }
        }
    }
}
