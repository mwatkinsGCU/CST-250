﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinesweeperLogic
{
    public class Cell
    {
        // create the properties with get and set
        public int Row { get; set; }
        public int Col { get; set; }
        public bool IsVisited { get; set; }
        public bool IsBomb { get; set; }
        public bool IsFlagged { get; set; }
        public int NumberOfBombNeighbors { get; set; }
        public bool HasReward { get; set; }

        // default constructor
        public Cell()
        {
            Row = -1;
            Col = -1;
            IsVisited = false;
            IsBomb = false;
            IsFlagged = false;
            NumberOfBombNeighbors = 0;
        }

        // parameterized constructor only with rows and columns
        public Cell(int row, int col)
        {
            Row = row;
            Col = col;
        }
    }
}
