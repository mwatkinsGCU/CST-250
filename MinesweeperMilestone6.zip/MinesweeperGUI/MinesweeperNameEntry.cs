﻿using MinesweeperLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MinesweeperGUI
{
    public partial class MinesweeperNameEntry : Form
    {
        // use for transferring score to high scores table
        int score;
        // use for transferring gameScoreList to high scores table
        List<GameStat> gameStats;

        TimeSpan time;

        // use for showing High Score table
        MinesweeperHighScores highScores;

        public MinesweeperNameEntry(int score, List<GameStat> gameScoreList, TimeSpan time)
        {
            InitializeComponent();
            this.score = score;
            gameStats = gameScoreList;
            this.time = time;
            lblScore.Text = "Score: " + score.ToString();

        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            highScores = new MinesweeperHighScores(txtName.Text, score, gameStats, time);
            highScores.ShowDialog();
            this.Close();
        }
    }
}
