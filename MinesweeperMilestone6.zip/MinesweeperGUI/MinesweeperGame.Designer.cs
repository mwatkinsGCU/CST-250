﻿namespace MinesweeperGUI
{
    partial class MinesweeperGame
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelMinesweeperBoard = new Panel();
            lblStart = new Label();
            lblUpdatingTime = new Label();
            lblScore = new Label();
            lblUpdatingScore = new Label();
            btnRestart = new Button();
            timerCheckTime = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // panelMinesweeperBoard
            // 
            panelMinesweeperBoard.Location = new Point(12, 12);
            panelMinesweeperBoard.Name = "panelMinesweeperBoard";
            panelMinesweeperBoard.Size = new Size(800, 800);
            panelMinesweeperBoard.TabIndex = 0;
            // 
            // lblStart
            // 
            lblStart.AutoSize = true;
            lblStart.Location = new Point(846, 44);
            lblStart.Name = "lblStart";
            lblStart.Size = new Size(54, 25);
            lblStart.TabIndex = 1;
            lblStart.Text = "Time:";
            // 
            // lblUpdatingTime
            // 
            lblUpdatingTime.AutoSize = true;
            lblUpdatingTime.Location = new Point(846, 83);
            lblUpdatingTime.Name = "lblUpdatingTime";
            lblUpdatingTime.Size = new Size(47, 25);
            lblUpdatingTime.TabIndex = 2;
            lblUpdatingTime.Text = "time";
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Location = new Point(846, 181);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(60, 25);
            lblScore.TabIndex = 3;
            lblScore.Text = "Score:";
            // 
            // lblUpdatingScore
            // 
            lblUpdatingScore.AutoSize = true;
            lblUpdatingScore.Location = new Point(846, 223);
            lblUpdatingScore.Name = "lblUpdatingScore";
            lblUpdatingScore.Size = new Size(54, 25);
            lblUpdatingScore.TabIndex = 4;
            lblUpdatingScore.Text = "score";
            // 
            // btnRestart
            // 
            btnRestart.Location = new Point(923, 294);
            btnRestart.Name = "btnRestart";
            btnRestart.Size = new Size(112, 34);
            btnRestart.TabIndex = 5;
            btnRestart.Text = "Restart";
            btnRestart.UseVisualStyleBackColor = true;
            btnRestart.Click += BtnRestart_Click;
            // 
            // timerCheckTime
            // 
            timerCheckTime.Interval = 1000;
            timerCheckTime.Tick += TimerCheck_Tick;
            // 
            // MinesweeperGame
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1142, 831);
            Controls.Add(btnRestart);
            Controls.Add(lblUpdatingScore);
            Controls.Add(lblScore);
            Controls.Add(lblUpdatingTime);
            Controls.Add(lblStart);
            Controls.Add(panelMinesweeperBoard);
            KeyPreview = true;
            Name = "MinesweeperGame";
            Text = "Minesweeper";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelMinesweeperBoard;
        private Label lblStart;
        private Label lblUpdatingTime;
        private Label lblScore;
        private Label lblUpdatingScore;
        private Button btnRestart;
        private System.Windows.Forms.Timer timerCheckTime;
    }
}
