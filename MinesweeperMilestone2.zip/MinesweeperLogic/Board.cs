﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MinesweeperLogic
{
    public class Board
    {
        // create the properties with get and set
        public int Size { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public Cell[,] Cells { get; set; }
        public double DiffPercent { get; set; }
        public int RewardsRemaining { get; set; }
        public enum GameState { InProgress, Won, Lost }
        public int numBombs { get; set; }
        public int numVisited {  get; set; }

        // constructor
        public Board(int size, double difficulty)
        {
            Size = size;
            DiffPercent = difficulty;
            Cells = new Cell[size, size];
            RewardsRemaining = 0;
            InitializeBoard();
        }

        // method to call submethods to init the board
        private void InitializeBoard()
        {
            // init Cells array
            for (int idxR = 0; idxR < Size; idxR++)
            {
                for (int idxC = 0; idxC < Size; idxC++)
                {
                    Cells[idxR, idxC] = new Cell(idxR, idxC);

                }
            }
            SetupBombs();
            SetupReward();
            CountBombsNearby();
            StartTime = DateTime.Now;
        }
        
        // used when a player selects a cell and chooses to use the reward
        public void UseSpecialReward()
        {

        }

        // used after the game is over to calculate the final score
        public int DetermineFinalScore()
        {
            return 0;
        }

        // method to get number of visited cells on board
        public int GetVisited()
        {
            foreach (Cell cell in Cells)
            {
                if (cell.IsVisited)
                {
                    numVisited++;
                }
            }
            return numVisited;
        }

        // method to determine if a cell is on the board
        public bool IsCellOnBoard(int row, int col)
        {
            if (row < 0 || col < 0)
                return false;

            if (row >= Size || col >= Size)
                return false;

            return true;
        }

        // method to set up bombs across the board
        private void SetupBombs()
        {
            foreach (Cell cell in Cells)
            {
                // generate a random number between 0 and 1
                Random rand = new Random();
                double genDiff = rand.NextDouble();
                
                // check if random number is less than or equal to difficulty level
                if (genDiff <= DiffPercent)
                {
                    cell.IsBomb = true;
                    numBombs++;
                }
                else
                {
                    cell.IsBomb = false;
                }
            }
        }

        // method to set up bombs across the board
        private void SetupReward()
        {
            // generate two random numbers between 0 and the board size, will be used as row and column of the reward
            Random rand = new Random();
            int rewardRow = rand.Next(0, Size);
            int rewardCol = rand.Next(0, Size);

            Cells[rewardRow, rewardCol].HasReward = true;
        }

        // method to determine how many neighbors are bombs
        private void CountBombsNearby()
        {
            for (int idxRow = 0; idxRow < Size; idxRow++)
            {
                for (int idxCol = 0; idxCol < Size; idxCol++)
                {
                    if (Cells[idxRow, idxCol].IsBomb)
                    {
                        // if cell is a bomb, set neighbors to 9
                        Cells[idxRow, idxCol].NumberOfBombNeighbors = 9;
                    }
                    else
                    {
                        // check surrounding cells for bombs and set result to the property
                        Cells[idxRow, idxCol].NumberOfBombNeighbors = GetNumberOfBombNeighbors(idxRow, idxCol);
                    }
                }
            }
        }

        // helper method to determine the number of bomb neighbors for each cell
        private int GetNumberOfBombNeighbors(int row, int col)
        {
            int total = 0;

            if (IsCellOnBoard(row - 1, col - 1))
            {
                if (Cells[(row - 1), (col - 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row - 1, col))
            {
                if (Cells[(row - 1), (col)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row - 1, col + 1))
            {
                if (Cells[(row - 1), (col + 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row, col - 1))
            {
                if (Cells[(row), (col - 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row, col + 1))
            {
                if (Cells[(row), (col + 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row + 1, col - 1))
            {
                if (Cells[(row + 1), (col - 1)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row + 1, col))
            {
                if (Cells[(row + 1), (col)].IsBomb)
                {
                    total++;
                }
            }
            if (IsCellOnBoard(row + 1, col + 1))
            {
                if (Cells[(row + 1), (col + 1)].IsBomb)
                {
                    total++;
                }
            }

            return total;
        }

        // method to determine the game state
        private GameState DetermineGameState()
        {
            // set game state to in progress all the time for now
            GameState state = new GameState();
            state = GameState.InProgress;
            return state;
        }
    }
}
