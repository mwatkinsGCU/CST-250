﻿namespace MinesweeperGUI
{
    partial class MinesweeperNameEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblWinMsg = new Label();
            txtName = new TextBox();
            lblScore = new Label();
            btnOK = new Button();
            SuspendLayout();
            // 
            // lblWinMsg
            // 
            lblWinMsg.AutoSize = true;
            lblWinMsg.Location = new Point(12, 9);
            lblWinMsg.Name = "lblWinMsg";
            lblWinMsg.Size = new Size(467, 25);
            lblWinMsg.TabIndex = 0;
            lblWinMsg.Text = "Congratulations, you won! Please enter your name below:";
            // 
            // txtName
            // 
            txtName.Location = new Point(12, 37);
            txtName.Name = "txtName";
            txtName.Size = new Size(467, 31);
            txtName.TabIndex = 1;
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Location = new Point(12, 71);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(65, 25);
            lblScore.TabIndex = 2;
            lblScore.Text = "Score: ";
            // 
            // btnOK
            // 
            btnOK.Location = new Point(178, 129);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(112, 34);
            btnOK.TabIndex = 3;
            btnOK.Text = "OK";
            btnOK.UseVisualStyleBackColor = true;
            btnOK.Click += BtnOK_Click;
            // 
            // MinesweeperNameEntry
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(500, 180);
            Controls.Add(btnOK);
            Controls.Add(lblScore);
            Controls.Add(txtName);
            Controls.Add(lblWinMsg);
            Name = "MinesweeperNameEntry";
            Text = "MinesweeperNameEntry";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblWinMsg;
        private TextBox txtName;
        private Label lblScore;
        private Button btnOK;
    }
}