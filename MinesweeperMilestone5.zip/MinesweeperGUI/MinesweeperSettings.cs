﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MinesweeperLogic;

namespace MinesweeperGUI
{
    public partial class MinesweeperSettings : Form
    {
        public int Size { get; set; }
        public double Difficulty { get; set; }
        public MinesweeperSettings()
        {
            InitializeComponent();
        }

        private void TrackSize_Scroll(object sender, EventArgs e)
        {
            Size = trackSize.Value;
            lblSize.Text = "Size: " + Size.ToString();
        }

        private void TaskDifficulty_Scroll(object sender, EventArgs e)
        {
            Difficulty = (double)trackBombs.Value / 100;
            lblPercentBombs.Text = "Percent Bombs: " + trackBombs.Value.ToString() + "%";
        }

        private void BtnPlay_Click(object sender, EventArgs e)
        {
            MinesweeperGame minesweeperGame = new MinesweeperGame(Size, Difficulty, this);
            minesweeperGame.ShowDialog();
        }
    }
}
