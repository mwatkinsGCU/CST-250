﻿using MinesweeperLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MinesweeperGUI
{
    public partial class MinesweeperHighScores : Form
    {
        GameStat gameStat;

        BindingSource bindingSource = new BindingSource();

        public List<GameStat> statList = new List<GameStat>();
        public MinesweeperHighScores(string name, int score, List<GameStat> gameStats)
        {
            statList = gameStats;
            gameStat = new GameStat();
            gameStat.Name = name;
            gameStat.Score = score;
            gameStat.GameTime = DateTime.Now;
            gameStat.Id = statList.Count + 1;
            statList.Add(gameStat);

            InitializeComponent();

            bindingSource.DataSource = statList;

            gvHighScores.DataSource = bindingSource.DataSource;
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void StripName_Click(object sender, EventArgs e)
        {
            statList.Sort((x, y) => x.Name.CompareTo(y.Name));
            bindingSource.ResetBindings(false);
            gvHighScores.Refresh();
        }

        private void StripDate_Click(object sender, EventArgs e)
        {
            statList.Sort((x, y) => x.GameTime.CompareTo(y.GameTime));
            bindingSource.ResetBindings(false);
            gvHighScores.Refresh();
        }

        private void StripScore_Click(object sender, EventArgs e)
        {
            statList.Sort((x, y) => x.Score.CompareTo(y.Score));
            statList.Reverse();
            bindingSource.ResetBindings(false);
            gvHighScores.Refresh();
        }
    }
}
