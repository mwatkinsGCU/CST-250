﻿namespace MinesweeperGUI
{
    partial class MinesweeperSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPlay = new Label();
            trackSize = new TrackBar();
            lblSize = new Label();
            lblPercentBombs = new Label();
            trackBombs = new TrackBar();
            btnPlay = new Button();
            ((System.ComponentModel.ISupportInitialize)trackSize).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBombs).BeginInit();
            SuspendLayout();
            // 
            // lblPlay
            // 
            lblPlay.AutoSize = true;
            lblPlay.Location = new Point(12, 9);
            lblPlay.Name = "lblPlay";
            lblPlay.Size = new Size(153, 25);
            lblPlay.TabIndex = 0;
            lblPlay.Text = "Play Minesweeper";
            // 
            // trackSize
            // 
            trackSize.Location = new Point(12, 98);
            trackSize.Maximum = 15;
            trackSize.Minimum = 5;
            trackSize.Name = "trackSize";
            trackSize.Size = new Size(409, 69);
            trackSize.TabIndex = 1;
            trackSize.Value = 5;
            trackSize.Scroll += TrackSize_Scroll;
            // 
            // lblSize
            // 
            lblSize.AutoSize = true;
            lblSize.Location = new Point(12, 57);
            lblSize.Name = "lblSize";
            lblSize.Size = new Size(62, 25);
            lblSize.TabIndex = 2;
            lblSize.Text = "Size: 5";
            // 
            // lblPercentBombs
            // 
            lblPercentBombs.AutoSize = true;
            lblPercentBombs.Location = new Point(12, 170);
            lblPercentBombs.Name = "lblPercentBombs";
            lblPercentBombs.Size = new Size(164, 25);
            lblPercentBombs.TabIndex = 4;
            lblPercentBombs.Text = "Percent Bombs: 5%";
            // 
            // trackBombs
            // 
            trackBombs.Location = new Point(12, 211);
            trackBombs.Maximum = 25;
            trackBombs.Minimum = 5;
            trackBombs.Name = "trackBombs";
            trackBombs.Size = new Size(409, 69);
            trackBombs.TabIndex = 3;
            trackBombs.Value = 5;
            trackBombs.Scroll += TaskDifficulty_Scroll;
            // 
            // btnPlay
            // 
            btnPlay.Location = new Point(154, 286);
            btnPlay.Name = "btnPlay";
            btnPlay.Size = new Size(112, 34);
            btnPlay.TabIndex = 5;
            btnPlay.Text = "Play";
            btnPlay.UseVisualStyleBackColor = true;
            btnPlay.Click += BtnPlay_Click;
            // 
            // MinesweeperSettings
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(434, 343);
            Controls.Add(btnPlay);
            Controls.Add(lblPercentBombs);
            Controls.Add(trackBombs);
            Controls.Add(lblSize);
            Controls.Add(trackSize);
            Controls.Add(lblPlay);
            Name = "MinesweeperSettings";
            Text = "Start A New Game";
            ((System.ComponentModel.ISupportInitialize)trackSize).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBombs).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPlay;
        private TrackBar trackSize;
        private Label lblSize;
        private Label lblPercentBombs;
        private TrackBar trackBombs;
        private Button btnPlay;
    }
}