using Microsoft.VisualBasic.Devices;
using Microsoft.Win32;
using MinesweeperLogic;
using static MinesweeperLogic.Board;

namespace MinesweeperGUI
{
    public partial class MinesweeperGame : Form
    {
        // instance of the Board class used to manage the game data
        Board board;
        // 2D array of buttons used to represent the game board in the GUI
        Button[,] buttons;
        // To track the currently hovered button
        Button currentHoveredButton = null;
        // used for restarting
        MinesweeperSettings Settings;

        // used for adding names to winning games
        MinesweeperNameEntry MinesweeperNameEntry;
        // used to store winning games
        List<GameStat> GameStatList = new List<GameStat>();

        // getting the size and difficulty from secondary form and setting up the game board
        public MinesweeperGame(int size, double difficulty, MinesweeperSettings settings)
        {
            board = new Board(size, difficulty);
            buttons = new Button[size, size];
            Settings = settings;
            InitializeComponent();
            SetupButtons();
            timerCheckTime.Start();
        }

        // populate the panel with buttons in a grid
        private void SetupButtons()
        {
            // calculate the button size. panel width / 8 = size of one button
            int buttonSize = panelMinesweeperBoard.Width / board.Size;
            // force the panel to be square
            panelMinesweeperBoard.Height = panelMinesweeperBoard.Width;
            // create the buttons
            for (int row = 0; row < board.Size; row++)
            {
                for (int col = 0; col < board.Size; col++)
                {
                    // dynamically create a button and place it on the panel
                    buttons[row, col] = new Button();
                    // set button font size to smaller
                    buttons[row, col].Font = new Font("Segoe UI", 7);
                    // button is square
                    buttons[row, col].Width = buttonSize;
                    buttons[row, col].Height = buttonSize;
                    // left = left side of button. Each button is buttonSize wide
                    buttons[row, col].Left = row * buttonSize;
                    buttons[row, col].Top = col * buttonSize;
                    // set image layout to stretch
                    buttons[row, col].BackgroundImageLayout = ImageLayout.Stretch;
                    // attach events to the button
                    buttons[row, col].Click += GridButtons_Click; // manually add this event handler to the buttons
                    buttons[row, col].MouseDown += GridButtons_MouseDown; // manually add this event handler to the buttons (allows for right-click to flag)
                    buttons[row, col].MouseEnter += GridButton_MouseEnter; // manually add this event handler to the buttons (allows for checking what button is hovered)
                    buttons[row, col].MouseLeave += GridButton_MouseLeave; // manually add this event handler to the buttons (allows for checking what button is hovered)
                    // the tag property can store an object. We will use it to store the row and column of the button.
                    buttons[row, col].Tag = new Point(row, col);

                    // set the color of the button to be gray since it has not been visited yet
                    Random random = new Random();
                    int randNum = random.Next(0, 2);
                    if (randNum == 0)
                    {
                        buttons[row, col].BackgroundImage = Image.FromFile("Tile 1.png");
                    }
                    else
                    {
                        buttons[row, col].BackgroundImage = Image.FromFile("Tile 2.png");
                    }

                    // add the button to the panel
                    panelMinesweeperBoard.Controls.Add(buttons[row, col]);
                }
            }

            // Listen for a keypress at the form level
            this.KeyDown += MinesweeperGame_KeyDown;
        }

        private void GridButtons_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right) // Check if right-click
            {
                Button b = (Button)sender;
                Point p = (Point)b.Tag;
                int row = p.X;
                int col = p.Y;

                // Toggle the flagged state of the cell
                ToggleFlag(row, col);
            }
        }

        private void ToggleFlag(int row, int col)
        {
            // Toggle the flag state in the Cell
            board.Cells[row, col].IsFlagged = !board.Cells[row, col].IsFlagged;

            // Update the button's appearance based on the flag state
            if (board.Cells[row, col].IsFlagged)
            {
                buttons[row, col].BackgroundImage = Image.FromFile("Flag.png");
            }
            else
            {
                Random rnd = new Random();
                int rndNum = rnd.Next(0, 2);
                if (rndNum == 0)
                    buttons[row, col].BackgroundImage = Image.FromFile("Tile 1.png");
                else
                    buttons[row, col].BackgroundImage = Image.FromFile("Tile 2.png");
            }
        }

        private void GridButtons_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            Point p = (Point)b.Tag;
            int row = p.X;
            int col = p.Y;

            // Check if the cell was already visited
            if (!board.Cells[row, col].IsVisited)
            {
                // Check if it's a bomb
                if (board.Cells[row, col].IsBomb)
                {
                    board.Cells[row, col].IsVisited = true;
                    buttons[row, col].BackgroundImage = Image.FromFile("Skull.png");
                    GameOver(false);
                }
                else if (board.Cells[row, col].HasReward)
                {
                    board.Cells[row, col].IsVisited = true;
                    // Reveal the reward
                    buttons[row, col].BackgroundImage = Image.FromFile("Gold.png");

                    // Handle collecting the reward here
                    CollectReward(row, col);
                    UpdateBoard();
                }
                else
                {
                    // Handle number of bomb neighbors as usual
                    if (board.Cells[row, col].NumberOfBombNeighbors != 0)
                    {
                        board.Cells[row, col].IsVisited = true;
                        buttons[row, col].BackgroundImage = GetImageForBombCount(board.Cells[row, col].NumberOfBombNeighbors);
                    }
                    else
                    {
                        buttons[row, col].BackgroundImage = GetImageForBombCount(board.Cells[row, col].NumberOfBombNeighbors);
                        FloodFill(row, col, UpdateButton);
                    }
                }
            }

            if (CheckWinCondition())
            {
                GameOver(true);
            }
        }

        // method to return image based on the number of bomb neighbors
        public Image GetImageForBombCount(int bombCount)
        {
            return bombCount switch
            {
                1 => Image.FromFile("Number 1.png"),
                2 => Image.FromFile("Number 2.png"),
                3 => Image.FromFile("Number 3.png"),
                4 => Image.FromFile("Number 4.png"),
                5 => Image.FromFile("Number 5.png"),
                6 => Image.FromFile("Number 6.png"),
                7 => Image.FromFile("Number 7.png"),
                8 => Image.FromFile("Number 8.png"),
                _ => Image.FromFile("Tile Flat.png"),
            };
        }

        // method to collect a reward
        public void CollectReward(int row, int col)
        {
            if (board.Cells[row, col].HasReward)
            {
                board.Cells[row, col].HasReward = false;
                board.RewardsRemaining++;
                MessageBox.Show("You have collected a reward!");
            }
        }

        private void FloodFill(int row, int col, Action<int, int, Image> updateButton)
        {
            // Check if the cell is valid
            if (row < 0 || row >= board.Cells.GetLength(0) || col < 0 || col >= board.Cells.GetLength(1))
                return;

            // If the cell is already visited, return
            if (board.Cells[row, col].IsVisited)
                return;

            // Perform the update using the provided delegate
            if (board.Cells[row, col].IsBomb)
            {
                return; // Stop if it's a bomb
            }

            // Check for rewards
            if (board.Cells[row, col].HasReward)
            {
                return; // Stop if it's a reward
            }

            // Mark the cell as visited
            board.Cells[row, col].IsVisited = true;

            // If there are bomb neighbors, end the loop
            if (board.Cells[row, col].NumberOfBombNeighbors > 0)
            {
                board.Cells[row, col].IsVisited = false; // Unmark the cell as visited
                return;
            }

            // Update button to empty and continue flood fill on neighboring cells
            updateButton(row, col, GetImageForBombCount(board.Cells[row, col].NumberOfBombNeighbors));
            FloodFill(row, col - 1, updateButton); // West
            FloodFill(row, col + 1, updateButton); // East
            FloodFill(row - 1, col, updateButton); // North
            FloodFill(row + 1, col, updateButton); // South
        }

        private bool CheckWinCondition()
        {
            foreach (Cell cell in board.Cells)
            {
                // If any non-bomb cell is not visited, return false
                if (!cell.IsBomb && !cell.IsVisited)
                {
                    return false;
                }
            }
            // If all non-bomb cells are visited, the player has won
            board.EndTime = DateTime.Now;
            board.DetermineScore();
            return true;
        }

        private void GameOver(bool hasWon)
        {
            if (hasWon)
            {
                timerCheckTime.Stop();
                board.EndTime = DateTime.Now;
                MessageBox.Show("Congratulations! You've won the game!\nFinal Score: " + board.DetermineScore(), "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MinesweeperNameEntry = new MinesweeperNameEntry(board.DetermineScore(), GameStatList);
                MinesweeperNameEntry.ShowDialog();
            }
            else
            {
                timerCheckTime.Stop();
                board.EndTime = DateTime.Now;
                MessageBox.Show("Boom! You clicked on a bomb. Game over!\nFinal Score: " + board.DetermineScore(), "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            // disable all buttons after the game ends
            foreach (Button button in buttons)
            {
                button.Enabled = false;
            }
        }


        private void UpdateButton(int row, int col, Image image)
        {
            // Update the button UI
            buttons[row, col].BackgroundImage = image;
        }

        // update the board after finding a reward
        private void UpdateBoard()
        {
            lblUpdatingScore.Text = board.DetermineScore(DateTime.Now - board.StartTime).ToString();

            foreach (Cell cell in board.Cells)
            {
                if (cell.IsVisited)
                {
                    if (cell.NumberOfBombNeighbors > 0)
                    {
                        UpdateButton(cell.Row, cell.Col, GetImageForBombCount(cell.NumberOfBombNeighbors));
                    }
                    else
                    {
                        UpdateButton(cell.Row, cell.Col, GetImageForBombCount(cell.NumberOfBombNeighbors));
                    }
                }
            }
        }

        private void TimerCheck_Tick(object sender, EventArgs e)
        {
            TimeSpan elapsed = DateTime.Now - board.StartTime;

            string time = elapsed.ToString(@"hh\:mm\:ss");

            lblUpdatingTime.Text = time;
        }

        // Track the currently hovered button
        private void GridButton_MouseEnter(object sender, EventArgs e)
        {
            currentHoveredButton = (Button)sender;
        }

        private void GridButton_MouseLeave(object sender, EventArgs e)
        {
            currentHoveredButton = null;
        }

        private void MinesweeperGame_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space && currentHoveredButton != null)
            {
                Point p = (Point)currentHoveredButton.Tag;
                int row = p.X;
                int col = p.Y;

                if (board.RewardsRemaining > 0)
                {
                    // Use the reward on the hovered cell
                    MessageBox.Show(board.UseSpecialReward(row, col));
                }
                else
                {
                    MessageBox.Show("No rewards remaining!");
                }
            }
        }

        public void RestartGame()
        {
            // Clear the current buttons from the panel
            panelMinesweeperBoard.Controls.Clear();

            // Create a new board with the same size and difficulty
            board = new Board(Settings.Size, Settings.Difficulty);

            // Recreate the buttons for the new game board
            SetupButtons();

            timerCheckTime.Start();
        }

        // Button click event handler to restart the game
        private void BtnRestart_Click(object sender, EventArgs e)
        {
            RestartGame();
        }
    }
}
